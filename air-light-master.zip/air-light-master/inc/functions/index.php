<?php
/**
 * Silence is golden.
 *
 * Nothing to see here.
 *
 * @Author:		Roni Laukkarinen
 * @Date:   		2022-01-03 14:27:00
 * @Last Modified by:   Roni Laukkarinen
 * @Last Modified time: 2022-01-03 15:35:25
 *
 * @package air-light
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 */

 // Silence is golden.
